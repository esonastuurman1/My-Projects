/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.login;

/**
 *
 * @author Esona
 */
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login {
     String username;
     String password;
     String firstName;
     String lastName;

    // this method is used to check if the username is valid
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // this method is used to check if the password meets the complexity requirements
    public boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    // this method is used to register the user and check the validity of the username and password
    public String registerUser(String username, String password, String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;

        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }

        this.username = username;
        this.password = password;
        return "Username and password successfully captured.";
    }

    // this method is used to log in the user by checking the stored username and password
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    // this method is used to return the login status message
    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    //method to demonstrate the login and registration functionality
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();

        // Registration process
        System.out.println("Register a new account");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter username (max 5 characters and must contain '_'): ");
        String username = scanner.nextLine();
        System.out.print("Enter password (must be at least 8 characters, with a capital letter, number, and special character): ");
        String password = scanner.nextLine();

        String registrationMessage = loginSystem.registerUser(username, password, firstName, lastName);
        System.out.println(registrationMessage);

        if (registrationMessage.equals("Username and password successfully captured.")) {
            // the login process
            System.out.println("\nLogin to your account");
            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();
            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();

            boolean loginStatus = loginSystem.loginUser(loginUsername, loginPassword);
            System.out.println(loginSystem.returnLoginStatus(loginStatus));
        }
        
        scanner.close();
    }
}

