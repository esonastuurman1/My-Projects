
package com.mycompany.login;

import javax.swing.JOptionPane;



class Login {
    String user;
    String password;
    String firstName;
    String lastName;

    
    boolean checkUserName(String user) {
        return user.length() >= 6 && user.contains("_");
    }
     boolean checkPassword(String password) {
        boolean hasUpperCase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecialChar = !password.matches("[A-Za-z0-9 ]*");
        if (password.length() >= 8 && hasUpperCase && hasNumber && hasSpecialChar) {
            return true;
        } else {
            return false;
        }
    }


    // Method to prompt user for registration details
    void promptUser() {
        // Prompt for first name and last name
        firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
        lastName = JOptionPane.showInputDialog(null, "Enter your last name:");

        // Prompt for username
        user = JOptionPane.showInputDialog(null,
                "Enter a username (at least 6 characters and contain an underscore):");
        while (!checkUserName(user)) {
            user = JOptionPane.showInputDialog(null,
                    "Invalid username. Please enter a username (at least 6 characters and contain an underscore):");
        }

        // Prompt for password with special character validation
        password = JOptionPane.showInputDialog(null, "Enter a password (at least 8 characters and contain a special character):");
        while (password.length() < 8 || !password.matches(".*[!@#$%^&*()+\\-=\\[\\]{};':\"\\\\|,.<>?].*")) {
            password = JOptionPane.showInputDialog(null, "Invalid password. Please enter a password (at least 8 characters and contain a special character):");
        }
    }

    // Method to check if the entered username and password match the registered user's credentials
    boolean login(String enteredUser, String enteredPassword) {
        return enteredUser.equals(user) && enteredPassword.equals(password);
    }

    public static void main(String[] args) {
        Login user1 = new Login();
        user1.promptUser();

        // Prompt for username and password for login
        String enteredUser = JOptionPane.showInputDialog(null, "Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog(null, "Enter your password:");

        if (user1.login(enteredUser, enteredPassword)) {
            // User Authentication
            boolean authenticated = authenticate();

            if (authenticated) {
                // Welcome Message to easykanban
                JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");

                // Numeric Menu
                int option = 0;
                int taskCount = getTaskCount();
                Task[] tasks = new Task[taskCount];
                int taskIndex = 0;

                do {
                    // Display menu options
                    option = Integer.parseInt(JOptionPane.showInputDialog("Choose an option:\n" +
                            "1. Add tasks\n" +
                            "2. Show report\n" +
                            "3. Quit"));

                    switch (option) {
                        case 1:
                            if (taskIndex < taskCount) {
                                Task task = getTask(taskIndex);
                                if (task != null) {
                                    tasks[taskIndex] = task;
                                    taskIndex++;
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "You have already entered " + taskCount + " tasks.");
                            }
                            break;
                        case 2:
                            JOptionPane.showMessageDialog(null, "Coming Soon");
                            break;
                        case 3:
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid option");
                            break;
                    }
                } while (option != 3);

                // Task Details Display
                StringBuilder output = new StringBuilder();
                int totalDuration = 0;

                for (Task task : tasks) {
                    if (task != null) {
                        output.append("Task Status: ").append(task.getStatus()).append("\n");
                        output.append("Developer Details: ").append(task.getDeveloper()).append("\n");
                        output.append("Task Number: ").append(task.getNumber()).append("\n");
                        output.append("Task Name: ").append(task.getName()).append("\n");

                        if (task.getDescription().length() > 50) {
                            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                        } else {
                            output.append("Task Description: ").append(task.getDescription()).append("\n");
                            output.append("Task ID: ").append(task.getID()).append("\n");
                            output.append("Task Duration: ").append(task.getDuration()).append(" hours\n\n");

                            totalDuration += task.getDuration();
                        }
                    }
                }

                JOptionPane.showMessageDialog(null, output.toString());

                // Total Task Hours must Display
                JOptionPane.showMessageDialog(null, "Total Task Duration: " + totalDuration + " hours");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
        }
        
        // Goodbye message
        JOptionPane.showMessageDialog(null, "Thank you for using EasyKanban, brought to you by Esona, Goodbye!");
    }

    private static boolean authenticate() {
        // TODO: Implement user authentication
        return true; // For demo purposes
    }

    private static int getTaskCount() {
        String input = JOptionPane.showInputDialog("Enter the number of tasks you wish to enter:");
        return Integer.parseInt(input);
    }

    private static Task getTask(int number) {
        String name = JOptionPane.showInputDialog("Enter the name of the task:");
        String description = JOptionPane.showInputDialog("Enter the description of the task:");
        String developer = JOptionPane.showInputDialog("Enter the developer assigned to the task:");
        String durationStr = JOptionPane.showInputDialog("Enter the estimated duration of the task in hours:");
        int duration = Integer.parseInt(durationStr);

        Task task = new Task(name, description, developer, duration, number);

        String[] parts = name.split(" ");
        String taskID = parts[0].substring(0, 2).toUpperCase()
                + ":" + number
                + ":" + developer.substring(developer.length() - 3).toUpperCase();
        task.setID(taskID);

        String[] statuses = {"To Do", "Done", "Doing"};
        int statusOption = JOptionPane.showOptionDialog(null, "Select the status of the task:", "Task Status",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                statuses, statuses[0]);
        String status = statuses[statusOption];
        task.setStatus(status);

        return task;
    }
    public void setUser(String user){
    this.user = user;
    }
    public void setPassword(String password){
    this.password = password;
    }
}

class Task {
    private String name;
    private String description;
    private String developer;
    private int duration;
    private int number;
    private String id;
    private String status = "To Do";

    public Task(String name, String description, String developer, int duration, int number) {
        this.name = name;
        this.description = description;
        this.developer = developer;
        this.duration = duration;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDeveloper() {
        return developer;
    }

    public int getDuration() {
        return duration;
    }

    public int getNumber() {
        return number;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}





   


