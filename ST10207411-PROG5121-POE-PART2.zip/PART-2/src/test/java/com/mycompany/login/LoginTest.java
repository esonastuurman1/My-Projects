/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.login;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Esona
 */
public class LoginTest {
    private Login loginSystem;

    @BeforeEach
    public void setup() {
        // Initialize a new Login object before each test
        loginSystem = new Login();
    }

    // Test for username correctly formatted
    @Test
    public void testCorrectlyFormattedUsername() {
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";

        String result = loginSystem.registerUser(username, password, firstName, lastName);
        assertEquals("Username and password successfully captured.", result);

        boolean loginResult = loginSystem.loginUser(username, password);
        assertEquals("Welcome John Doe, it is great to see you again.", loginSystem.returnLoginStatus(loginResult));
    }

    // Test for username incorrectly formatted
    @Test
    public void testIncorrectlyFormattedUsername() {
        String username = "kyle!!!!!!!";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";

        String result = loginSystem.registerUser(username, password, firstName, lastName);
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", result);
    }

    // Test for password meets complexity requirements
    @Test
    public void testPasswordMeetsComplexity() {
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";

        String result = loginSystem.registerUser(username, password, firstName, lastName);
        assertEquals("Username and password successfully captured.", result);
    }

    // Test for password does not meet complexity requirements
    @Test
    public void testPasswordDoesNotMeetComplexity() {
        String username = "kyl_1";
        String password = "password";
        String firstName = "John";
        String lastName = "Doe";

        String result = loginSystem.registerUser(username, password, firstName, lastName);
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", result);
    }

    // Test for successful login (assertTrue)
    @Test
    public void testLoginSuccessful() {
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";

        loginSystem.registerUser(username, password, firstName, lastName);
        boolean loginResult = loginSystem.loginUser(username, password);
        assertTrue(loginResult);
    }

    // Test for failed login (assertFalse)
    @Test
    public void testLoginFailed() {
        String username = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";

        loginSystem.registerUser(username, password, firstName, lastName);

        // Attempt login with wrong password
        boolean loginResult = loginSystem.loginUser(username, "wrongPassword");
        assertFalse(loginResult);
    }

    // Test username meets format requirements (assertTrue)
    @Test
    public void testUsernameMeetsFormat() {
        assertTrue(loginSystem.checkUserName("kyl_1"));
    }

    // Test username does not meet format requirements (assertFalse)
    @Test
    public void testUsernameDoesNotMeetFormat() {
        assertFalse(loginSystem.checkUserName("kyle!!!!!!!"));
    }

    // Test password meets complexity requirements (assertTrue)
    @Test
    public void testPasswordMeetsComplexityAssertTrue() {
        assertTrue(loginSystem.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    // Test password does not meet complexity requirements (assertFalse)
    @Test
    public void testPasswordDoesNotMeetComplexityAssertFalse() {
        assertFalse(loginSystem.checkPasswordComplexity("password"));
    }
}
