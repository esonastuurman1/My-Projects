/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.login;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskDescriptionTruncation_Success() {
        String description = "This is a task description that is less than 50 characters.";
        Task task = new Task("Test Task", description, "John Doe", 8, 1);
        assertEquals(description, task.getDescription());
    }

    @Test
    public void testTaskDescriptionTruncation_Failure() {
        String description = "This is a task description that is longer than 50 characters and will be truncated.";
        Task task = new Task("Test Task", description, "John Doe", 8, 1);
        assertEquals(description.substring(0, 50), task.getDescription());
    }

    @Test
    public void testTaskIdGeneration_Success() {
        Task task1 = new Task("Task 1", "Description", "Dev1", 5, 1);
        Task task2 = new Task("Task 2", "Description", "Dev2", 3, 2);
        assertFalse(task1.getId().equals(task2.getId()));
    }

    @Test